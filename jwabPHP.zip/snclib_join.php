<?php

    header('content-type: text/html; charset=utf-8'); 
    // 데이터베이스 접속 문자열. (db위치, 유저 이름, 비밀번호)
   include('dbCon.php');
    
    mysqli_query($connect,"SET NAMES UTF8");
   // 데이터베이스 선택
   mysqli_select_db($connect,"signdb");
 
   // 세션 시작
   session_start();
 


  $name=$_POST[u_name];
   $phone=$_POST[u_phone];
   $id = $_POST[u_id];
   $password1 = $_POST[u_pw]; 
   $password2 =$_POST[u_pwck];


  $sql = "INSERT INTO signtb(name,phone,id,password1,password2) VALUES('$name','$phone','$id', '$password1','$password2')";
  
 
   $result = mysqli_query($connect, $sql);
 
   if(!$result)
            die("mysql query error");
    else 
        echo("DB 입력 성공");
	
?>