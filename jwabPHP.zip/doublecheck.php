
<?php
//아이디 중복 체크하는 php

header('content-type: text/html; charset=utf-8'); 
  // 데이터베이스 접속 문자열. (db위치, 유저 이름, 비밀번호)
  include('dbCon.php');
  
  mysqli_query($connect,"SET NAMES UTF8");
  
  // 데이터베이스 선택
  mysqli_select_db($connect,"signdb");
 
  // 세션 시작
  session_start();

// 안드로이드에서 받아온 id값 저장하는 변수
 $id=$_POST['u_id'];

// 아이디 비교하여 실행시키는 쿼리문을 배열로 저장하여 result에 저장
$result = mysqli_fetch_array(mysqli_query($connect, "select id from signtb where id = '$id'"));

 
  // 쿼리 결과

 //id창에 아무것도 안들어가 있을때는 글자수가 0이 되므로 data값 안에 2가 출력
if(strlen($_POST['u_id'])=="0"){
      echo "2";
	  
}

// id창에 글자수가 1개 이상이면서 같은 아이디를 디비에서 찾을 수 없으면 data값 안에 1을 출력
else if (is_null($result) || $result==false){
   echo "1";   
	
}

// id창에 글자수가 1이상, 디비에서 같은 아이디를 찾으면 data에 0 출력

else{
   
    echo mysqli_errno($connect);   
 }

   //사용중인 아이디일 경우 0이 넘어감
   


?>
