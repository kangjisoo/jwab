<?php

	//connection: db address, id, password 전역변수 (connection 사용하는 php파일 전부 include 필요)
	$ipAddress = "localhost";	//"10.210.2.77:3307" (포트번호 같이 입력가능)
	$userId = "root";
	$userPassword = "0998";
	//$portNum = ???? (20.07.20 현재 미지정)
	

    header('content-type: text/html; charset=utf-8'); 
    // 데이터베이스 접속 문자열. (db위치, 유저 이름, 비밀번호)
    $connect=mysqli_connect($ipAddress, $userId, $userPassword) or  
        die( "SQL server에 연결할 수 없습니다.");
    
	//echo($ipAddress.$userId.$userPassword);
?>